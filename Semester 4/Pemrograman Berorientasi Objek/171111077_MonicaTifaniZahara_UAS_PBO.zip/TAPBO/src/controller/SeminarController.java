/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import interfaceMiler.InterfaceMiler;
import java.sql.Connection;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import koneksi.koneksi;
import model.SeminarModel;

/**
 *
 * @author WINDOWS 10
 */
public class SeminarController {

    private SeminarModel sm = new SeminarModel();

    public void tambahSeminar(SeminarModel seminarM) {

        sm.insert(seminarM);
    }
    
    public ArrayList selectSeminar() {
        return sm.select();
    }
    
}
