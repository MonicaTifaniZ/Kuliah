/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;
import koneksi.koneksi;
import view.AdminView;
import view.AnggotaView;
import view.LPJView;
import view.JadwalRKetupelView;
import view.MenuView;
import view.LoginView;

/**
 *
 * @author WINDOWS 10
 */
public class LoginController {

    LoginView login = new LoginView();

    public String loginsistem(String user, String pass) throws SQLException {
        String status = "";
        if (user.trim().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Username tidak boleh kosong!");
        } else if (pass.trim().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Password tidak boleh kosong!");
        } else {
            try {
                Connection conn = koneksi.getConnection();
                String sql = "SELECT * FROM user WHERE username='" + user + "'and password = '" + pass + "'";
                Statement s = conn.createStatement();
                ResultSet r = s.executeQuery(sql);
                while (r.next()) {
                    status = r.getString("STATUS");
                    
                    

                }
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(null, " Bye error : " + e.getMessage());
            }

        }
        return status;

    }

}
