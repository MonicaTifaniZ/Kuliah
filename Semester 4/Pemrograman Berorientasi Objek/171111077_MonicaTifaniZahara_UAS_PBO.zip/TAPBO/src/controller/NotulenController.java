/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import model.NotulenModel;

/**
 *
 * @author WINDOWS 10
 */
public class NotulenController {
    NotulenModel notulen = new NotulenModel();
    
    public void tambahNotulen(NotulenModel notul){
        notulen.insertNotulen(notul);
    }
    
    
}
