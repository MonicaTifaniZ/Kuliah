/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import interfaceMiler.InterfaceMiler;
import java.sql.Connection;
import java.util.ArrayList;
import model.PertemuanModel;
import model.RapatModel;

/**
 *
 * @author WINDOWS 10
 */
public class PertemuanController {

    private RapatModel objrapat = new RapatModel();

    public int genrateIDPertemuan() {

        return objrapat.genrateIDPertemuan();
    }

    public ArrayList lihatJadwal() {

        return objrapat.selectPertemuan();

    }
    
    public ArrayList lihatPertemuanValid(){
        return objrapat.selectValid();
    }

    public void validasiStatus(String kodeData , String statusPer , String statusKunci) {
        objrapat.update(kodeData , statusPer , statusKunci);
    }

//    public void tombolTolak(String kodeData) {
//        objrapat.tombolTolak(kodeData);
//    }

//    public void updateKunci(String kunci, String nilai) {
//        objrapat.update(kunci, nilai);
//    }
//
//    public void updateRuangan(String kunci, String nilai) {
//        objrapat.updateStatusRuangan(kunci, nilai);
//    }
    public void update(String kunci , String nilai, String kolom){ //kolom =  idruangan , status
        String tampung = "";
        if(kolom.equalsIgnoreCase("status_kunci")){
            tampung = "status_kunci='"+nilai+"'";
            
        } else if(kolom.equalsIgnoreCase("id_ruangan")){
            tampung = "id_ruangan='"+nilai+"'";
        }
        objrapat.update(kunci, tampung);
    }

}
