/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import interfaceMiler.InterfaceMiler;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.Date;
import javax.swing.JOptionPane;
import koneksi.koneksi;

/**
 *
 * @author Monica
 */

public class RapatModel extends PertemuanModel implements InterfaceMiler{

    private int idRapat;
    private String sifat;
    private String jangkaWaktu;
   

    public RapatModel(String sifat, String jangkaWaktu, int idPertemuan, String username, String idRuangan, String jenis, String tanggal, String jamMulai, String jamSelesai) {
        super(idPertemuan, username, idRuangan, jenis, tanggal, jamMulai, jamSelesai);
        this.sifat = sifat;
        this.jangkaWaktu = jangkaWaktu;
    }

    public RapatModel(String sifat, String jangkaWaktu) {
        this.sifat = sifat;
        this.jangkaWaktu = jangkaWaktu;
    }

    public RapatModel(int idPertemuan, String username, String idRuangan, String jenis, String tanggal, String jamMulai, String jamSelesai, String statusPertemuan, String statusKunci) {
        super(idPertemuan, username, idRuangan, jenis, tanggal, jamMulai, jamSelesai, statusPertemuan, statusKunci);
    }

    public RapatModel(int idRapat, String sifat, String jangkaWaktu, String idRuangan, String tanggal, String jamMulai, String statusPertemuan, String statusKunci) {
        super(idRuangan, tanggal, jamMulai, statusPertemuan, statusKunci);
        this.idRapat = idRapat;
        this.sifat = sifat;
        this.jangkaWaktu = jangkaWaktu;
    }

    public RapatModel() {

    }

    public RapatModel(int idRapat) {
        this.idRapat = idRapat;
    }

    public int getIdRapat() {
        return idRapat;
    }

    public void setIdRapat(int idRapat) {
        this.idRapat = idRapat;
    }

    public String getSifat() {
        return sifat;
    }

    public void setSifat(String sifat) {
        this.sifat = sifat;
    }

    public String getJangkaWaktu() {
        return jangkaWaktu;
    }

    public void setJangkaWaktu(String jangkaWaktu) {
        this.jangkaWaktu = jangkaWaktu;
    }

    public void insert(RapatModel data) {
        super.insert(data);
        try {
            String sql = "INSERT INTO RAPAT"
                    + " (ID_PERTEMUAN, SIFAT, JANGKA_WAKTU)"
                    + " VALUES ('" + data.getIdPertemuan() + "', '" + data.getSifat() + "' ,'" + data.getJangkaWaktu() + "')";

            java.sql.Connection conn = (Connection) koneksi.getConnection();
            java.sql.PreparedStatement pst = conn.prepareStatement(sql);
            pst.execute();
            JOptionPane.showMessageDialog(null, "Penyimpanan Data Berhasil");

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
    }

    @Override
    public ArrayList select() {
        ArrayList<RapatModel> daftar_jadwal = new ArrayList<RapatModel>();
        try {
            int no = 1;
            String sql = ("SELECT a.id_rapat , b.tanggal , a.sifat , a.jangka_waktu, b.jam_mulai "
                    + ", b.id_ruangan , b.status_pertemuan , b.status_kunci from rapat a join pertemuan b"
                    + " WHERE a.ID_PERTEMUAN = b.ID_PERTEMUAN");
            java.sql.Connection conn = (Connection) koneksi.getConnection();
            java.sql.Statement stm = conn.createStatement();
            java.sql.ResultSet res = stm.executeQuery(sql);

            while (res.next()) {
                daftar_jadwal.add(new RapatModel(res.getInt("ID_RAPAT"), res.getString("SIFAT"), res.getString("JANGKA_WAKTU"), res.getString("ID_RUANGAN"), res.getString("TANGGAL"), res.getString("JAM_MULAI"), res.getString("STATUS_PERTEMUAN"), res.getString("STATUS_KUNCI")));
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
        return daftar_jadwal;

    }
    
    public ArrayList selectPertemuan() {
        return super.select();

    }
    @Override
    public ArrayList selectValid(){
        return super.selectValid();
    }

  

}
