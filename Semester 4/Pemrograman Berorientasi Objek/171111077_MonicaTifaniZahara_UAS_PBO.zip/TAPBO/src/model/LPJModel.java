/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.sql.Connection;
import javax.swing.JOptionPane;
import koneksi.koneksi;

/**
 *
 * @author WINDOWS 10
 */
public class LPJModel extends SeminarModel {

    private int idLPJ;
    private String tujuan, deskripsi, sasaran;

    public LPJModel(String tujuan, String deskripsi, String sasaran, int idSeminar) {
        super(idSeminar);
        this.tujuan = tujuan;
        this.deskripsi = deskripsi;
        this.sasaran = sasaran;
    }

    

    
    public LPJModel() {
    }

    public int getIdLPJ() {
        return idLPJ;
    }

    public void setIdLPJ(int idLPJ) {
        this.idLPJ = idLPJ;
    }

    public String getTujuan() {
        return tujuan;
    }

    public void setTujuan(String tujuan) {
        this.tujuan = tujuan;
    }

    public String getDeskripsi() {
        return deskripsi;
    }

    public void setDeskripsi(String deskripsi) {
        this.deskripsi = deskripsi;
    }

    public String getSasaran() {
        return sasaran;
    }

    public void setSasaran(String sasaran) {
        this.sasaran = sasaran;
    }

    public void insertLPJ(LPJModel data) {
        try {
            String sql = "INSERT INTO lpj"
                    + " (ID_SEMINAR, TUJUAN , DESKRIPSI, SASARAN_KEGIATAN)"
                    + " VALUES ('" + data.getIdSeminar() + "', '" + data.getTujuan() + "' ,'" + data.getDeskripsi()
                    + "', '" + data.getSasaran() + "')";

            java.sql.Connection conn = (Connection) koneksi.getConnection();
            java.sql.PreparedStatement pst = conn.prepareStatement(sql);
            pst.execute();
            JOptionPane.showMessageDialog(null, "Penyimpanan Data Berhasil");

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
    }
}
