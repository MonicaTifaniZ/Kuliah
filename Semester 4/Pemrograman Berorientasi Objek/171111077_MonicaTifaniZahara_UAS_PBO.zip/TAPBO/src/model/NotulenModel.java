/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.sql.Connection;
import javax.swing.JOptionPane;
import koneksi.koneksi;

/**
 *
 * @author WINDOWS 10
 */
public class NotulenModel extends RapatModel {

    private int idNotulen;
    private String rapatKe, hasil;

    public NotulenModel(String rapatKe, String hasil, int idRapat) {
        super(idRapat);
        this.rapatKe = rapatKe;
        this.hasil = hasil;
    }

    public NotulenModel() {
    }

    public int getIdNotulen() {
        return idNotulen;
    }

    public void setIdNotulen(int idNotulen) {
        this.idNotulen = idNotulen;
    }

    public String getRapatKe() {
        return rapatKe;
    }

    public void setRapatKe(String rapatKe) {
        this.rapatKe = rapatKe;
    }

    public String getHasil() {
        return hasil;
    }

    public void setHasil(String hasil) {
        this.hasil = hasil;
    }

    public void insertNotulen(NotulenModel data) {
        try {
            String sql = "INSERT INTO notulen"
                    + " (ID_RAPAT, RAPAT_KE, HASIL)"
                    + " VALUES ('" + data.getIdRapat() + "', '" + data.getRapatKe() + "' ,'" + data.getHasil() + "')";

            java.sql.Connection conn = (Connection) koneksi.getConnection();
            java.sql.PreparedStatement pst = conn.prepareStatement(sql);
            pst.execute();
            JOptionPane.showMessageDialog(null, "Penyimpanan Data Berhasil");

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
    }

}
