/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import static com.sun.org.apache.xalan.internal.lib.ExsltDatetime.time;
import interfaceMiler.InterfaceMiler;
import view.JadwalRKetupelView;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Date;
import javax.swing.JOptionPane;
import koneksi.koneksi;

/**
 *
 * @author Monica
 */
public abstract class PertemuanModel implements InterfaceMiler{

    private int idPertemuan;
    private String username, idRuangan, jenis, tanggal;
    private String jamMulai, jamSelesai, statusPertemuan, statusKunci;

    public PertemuanModel(int idPertemuan, String username, String idRuangan, String jenis, String tanggal, String jamMulai, String jamSelesai) {
        this.idPertemuan = idPertemuan;
        this.username = username;
        this.idRuangan = idRuangan;
        this.jenis = jenis;
        this.tanggal = tanggal;
        this.jamMulai = jamMulai;
        this.jamSelesai = jamSelesai;
    }

    public PertemuanModel(int idPertemuan, String username, String idRuangan, String jenis, String tanggal, String jamMulai, String jamSelesai, String statusPertemuan, String statusKunci) {
        this.idPertemuan = idPertemuan;
        this.username = username;
        this.idRuangan = idRuangan;
        this.jenis = jenis;
        this.tanggal = tanggal;
        this.jamMulai = jamMulai;
        this.jamSelesai = jamSelesai;
        this.statusPertemuan = statusPertemuan;
        this.statusKunci = statusKunci;
    }

    public PertemuanModel(String idRuangan, String tanggal, String jamMulai, String statusPertemuan, String statusKunci) {
        this.idRuangan = idRuangan;
        this.tanggal = tanggal;
        this.jamMulai = jamMulai;
        this.statusPertemuan = statusPertemuan;
        this.statusKunci = statusKunci;
    }

    public PertemuanModel() {

    }

    public int getIdPertemuan() {
        return idPertemuan;
    }

    public void setIdPertemuan(int idPertemuan) {
        this.idPertemuan = idPertemuan;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getIdRuangan() {
        return idRuangan;
    }

    public void setIdRuangan(String idRuangan) {
        this.idRuangan = idRuangan;
    }

    public String getJenis() {
        return jenis;
    }

    public void setJenis(String jenis) {
        this.jenis = jenis;
    }

    public String getTanggal() {
        return tanggal;
    }

    public void setTanggal(String tanggal) {
        this.tanggal = tanggal;
    }

    public String getJamMulai() {
        return jamMulai;
    }

    public void setJamMulai(String jamMulai) {
        this.jamMulai = jamMulai;
    }

    public String getJamSelesai() {
        return jamSelesai;
    }

    public void setJamSelesai(String jamSelesai) {
        this.jamSelesai = jamSelesai;
    }

    public String getStatusPertemuan() {
        return statusPertemuan;
    }

    public void setStatusPertemuan(String statusPertemuan) {
        this.statusPertemuan = statusPertemuan;
    }

    public String getStatusKunci() {
        return statusKunci;
    }

    public void setStatusKunci(String statusKunci) {
        this.statusKunci = statusKunci;
    }

    public void insert(PertemuanModel daftarPertemuan) {
        try {
            String sql = "INSERT INTO PERTEMUAN"
                    + " (ID_PERTEMUAN, USERNAME , ID_RUANGAN, JENIS, TANGGAL, JAM_MULAI, JAM_SELESAI, STATUS_PERTEMUAN, STATUS_KUNCI)"
                    + " VALUES ('" + daftarPertemuan.getIdPertemuan() + "','" + daftarPertemuan.getUsername() + "','" + daftarPertemuan.getIdRuangan() + "','"
                    + daftarPertemuan.getJenis() + "','" + daftarPertemuan.getTanggal() + "','"
                    + daftarPertemuan.getJamMulai() + "','" + daftarPertemuan.getJamSelesai() + "','"
                    + "Menunggu Konfirmasi" + "','" + "Menunggu Konfirmasi')";

            java.sql.Connection conn = (Connection) koneksi.getConnection();
            java.sql.PreparedStatement pst = conn.prepareStatement(sql);
            pst.execute();

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
    }

    public int genrateIDPertemuan() {
        int nilai = 0;
        try {
            String sql = "SELECT COUNT(ID_PERTEMUAN) AS 'ID' FROM pertemuan";

            java.sql.Connection conn = (Connection) koneksi.getConnection();
            java.sql.PreparedStatement pst = conn.prepareStatement(sql);
            java.sql.ResultSet res = pst.executeQuery(sql);

            while (res.next()) {
                nilai = res.getInt("ID");
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
        return nilai + 1;
    }

    @Override
    public ArrayList select() {
        ArrayList<PertemuanModel> daftar_jadwal = new ArrayList<PertemuanModel>();
        try {
            int no = 1;
            String sql = ("SELECT * FROM pertemuan");
            java.sql.Connection conn = (Connection) koneksi.getConnection();
            java.sql.Statement stm = conn.createStatement();
            java.sql.ResultSet res = stm.executeQuery(sql);

            while (res.next()) {
                daftar_jadwal.add(new RapatModel(res.getInt("ID_PERTEMUAN"), res.getString("USERNAME"), res.getString("ID_RUANGAN"), res.getString("JENIS"), res.getString("TANGGAL"), res.getString("JAM_MULAI"), res.getString("JAM_SELESAI"), res.getString("STATUS_PERTEMUAN"), res.getString("STATUS_KUNCI")));
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
        return daftar_jadwal;

    }

     public ArrayList selectValid() {
        ArrayList<PertemuanModel> daftar_jadwal = new ArrayList<PertemuanModel>();
        try {
            int no = 1;
            String sql = ("SELECT * FROM pertemuan where status_pertemuan='Divalidasi'");
            java.sql.Connection conn = (Connection) koneksi.getConnection();
            java.sql.Statement stm = conn.createStatement();
            java.sql.ResultSet res = stm.executeQuery(sql);

            while (res.next()) {
                daftar_jadwal.add(new RapatModel(res.getInt("ID_PERTEMUAN"), res.getString("USERNAME"), res.getString("ID_RUANGAN"), res.getString("JENIS"), res.getString("TANGGAL"), res.getString("JAM_MULAI"), res.getString("JAM_SELESAI"), res.getString("STATUS_PERTEMUAN"), res.getString("STATUS_KUNCI")));
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
        return daftar_jadwal;

    }
    public void update(String kodeData , String statusPer , String statusKunci) {

        try {
            String sql = ("UPDATE pertemuan SET status_pertemuan ='"+statusPer+"' , status_kunci='"+statusKunci+"' where id_pertemuan='" + kodeData + "'");
            java.sql.Connection conn = (Connection) koneksi.getConnection();
            java.sql.PreparedStatement pst = conn.prepareStatement(sql);
            pst.execute();
            JOptionPane.showMessageDialog(null, "Kegiatan telah di "+statusPer);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Perubahan Data Gagal" + e.getMessage());
        }
    }
//
//    public void update(String Kunci , String nilai){
//        try {
//            String sql = ("UPDATE pertemuan SET status_kunci='"+nilai+"' where id_pertemuan='" +Kunci + "'");
//            java.sql.Connection conn = (Connection) koneksi.getConnection();
//            java.sql.PreparedStatement pst = conn.prepareStatement(sql);
//            pst.execute();
//            JOptionPane.showMessageDialog(null, "Berhasil!");
//        } catch (Exception e) {
//            JOptionPane.showMessageDialog(null, "Perubahan Data Gagal" + e.getMessage());
//        }
//    }
//    
//    public void updateStatusRuangan(String Kunci , String nilai){
//         try {
//            String sql = ("UPDATE pertemuan SET id_ruangan='"+nilai+"' where id_pertemuan='" +Kunci + "'");
//            java.sql.Connection conn = (Connection) koneksi.getConnection();
//            java.sql.PreparedStatement pst = conn.prepareStatement(sql);
//            pst.execute();
//            JOptionPane.showMessageDialog(null, "Berhasil!");
//        } catch (Exception e) {
//            JOptionPane.showMessageDialog(null, "Perubahan Data Gagal" + e.getMessage());
//        }
//    }
    public void update(String kunci , String nilai){
         try {
            String sql = ("UPDATE pertemuan SET "+nilai+" where id_pertemuan='" +kunci + "'");
            java.sql.Connection conn = (Connection) koneksi.getConnection();
            java.sql.PreparedStatement pst = conn.prepareStatement(sql);
            pst.execute();
            JOptionPane.showMessageDialog(null, "Berhasil!");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Perubahan Data Gagal" + e.getMessage());
        }
    }
}
