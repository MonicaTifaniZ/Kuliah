/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import interfaceMiler.InterfaceMiler;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.swing.JOptionPane;
import koneksi.koneksi;

/**
 *
 * @author Monica
 */
public class SeminarModel extends PertemuanModel implements InterfaceMiler{

    private int idSeminar;
    private String tema;
    private int targetPeserta;
    private String pemateri;
    private int htm;

    public SeminarModel(String tema, int targetPeserta, String pemateri, int htm, int idPertemuan, String username, String idRuangan, String jenis, String tanggal, String jamMulai, String jamSelesai) {
        super(idPertemuan, username, idRuangan, jenis, tanggal, jamMulai, jamSelesai);
        this.tema = tema;
        this.targetPeserta = targetPeserta;
        this.pemateri = pemateri;
        this.htm = htm;
    }

    public SeminarModel(int idSeminar, String tema, int targetPeserta, String pemateri, int htm) {
        this.idSeminar = idSeminar;
        this.tema = tema;
        this.targetPeserta = targetPeserta;
        this.pemateri = pemateri;
        this.htm = htm;
    }

    public SeminarModel(int idSeminar, String tema, String pemateri, String idRuangan, String tanggal, String jamMulai, String statusPertemuan, String statusKunci) {
        super(idRuangan, tanggal, jamMulai, statusPertemuan, statusKunci);
        this.idSeminar = idSeminar;
        this.tema = tema;
        this.pemateri = pemateri;
    }

    public SeminarModel(int idSeminar) {
        this.idSeminar = idSeminar;
    }

    public SeminarModel() {

    }

    public int getHtm() {
        return htm;
    }

    public void setHtm(int htm) {
        this.htm = htm;
    }

    public int getIdSeminar() {
        return idSeminar;
    }

    public void setIdSeminar(int idSeminar) {
        this.idSeminar = idSeminar;
    }

    public String getTema() {
        return tema;
    }

    public void setTema(String tema) {
        this.tema = tema;
    }

    public int getTargetPeserta() {
        return targetPeserta;
    }

    public void setTargetPeserta(int targetPeserta) {
        this.targetPeserta = targetPeserta;
    }

    public String getPemateri() {
        return pemateri;
    }

    public void setPemateri(String pemateri) {
        this.pemateri = pemateri;
    }

    public void insert(SeminarModel data) {
        super.insert(data);
        try {
            String sql = "INSERT INTO SEMINAR"
                    + " (ID_PERTEMUAN, TEMA, TARGET_PESERTA , PEMATERI, HTM)"
                    + " VALUES ('" + data.getIdPertemuan() + "', '" + data.getTema() + "' ,'" + data.getTargetPeserta()
                    + "', '" + data.getPemateri() + "', '" + data.getHtm() + "')";

            java.sql.Connection conn = (Connection) koneksi.getConnection();
            java.sql.PreparedStatement pst = conn.prepareStatement(sql);
            pst.execute();
            JOptionPane.showMessageDialog(null, "Penyimpanan Data Berhasil");

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
    }

    @Override
    public ArrayList select() {
        ArrayList<SeminarModel> daftar_jadwal = new ArrayList<SeminarModel>();
        try {
            int no = 1;
            String sql = ("SELECT a.id_seminar , a.tema , b.tanggal , a.pemateri, b.ID_RUANGAN "
                    + ",b.jam_mulai, b.status_pertemuan , b.status_kunci FROM seminar a JOIN pertemuan b "
                    + "WHERE a.ID_PERTEMUAN = b.ID_PERTEMUAN");
            java.sql.Connection conn = (Connection) koneksi.getConnection();
            java.sql.Statement stm = conn.createStatement();
            java.sql.ResultSet res = stm.executeQuery(sql);

            while (res.next()) {
                daftar_jadwal.add(new SeminarModel(res.getInt("ID_SEMINAR"), res.getString("TEMA"), res.getString("PEMATERI"), res.getString("ID_RUANGAN"), res.getString("TANGGAL"), res.getString("JAM_MULAI"), res.getString("STATUS_PERTEMUAN"), res.getString("STATUS_KUNCI")));

            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
        return daftar_jadwal;

    }
    
    public ArrayList selectPertemuan() {
        return super.select();

    }

}
